<?php
require_once __DIR__.'/accesodatos.php';
require_once __DIR__.'/usuario.php';
require_once __DIR__.'/local.php';