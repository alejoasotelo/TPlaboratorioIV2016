angular.module('app')
.controller('AuthCtrl', function($scope, $auth) {
	
	
});