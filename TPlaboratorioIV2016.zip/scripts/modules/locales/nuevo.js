angular.module('app')
.controller('LocalesNuevoCtrl', function($scope) {

});