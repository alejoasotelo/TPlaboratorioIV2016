angular.module('app')
.controller('UsuariosNuevoCtrl', function($scope) {

});